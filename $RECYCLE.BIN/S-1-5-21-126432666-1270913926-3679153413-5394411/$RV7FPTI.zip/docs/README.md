---
id: overview
title: ISMS Procedures
slug: /overview
---

# Note
This site is not to be used yet! Please refer to the original ISMS documentation.

# ISMS Procedures

This project documents the operational procedures that TeamcenterX Development teams undertake in order to deliver a secure product in compliance with ISO 27001 Policies. This page provides an overview. Detailed procedures, if required at all, are documented in the sub-folders.

## Scope

The CLOUD_ART development team is responsible for developing the SaaS Solution “TcX”. Our solution is available in AWS and Azure. This document describes how the CLOUD_ART team operationally complies with the ISMS and how the security architecture supports compliance. Other teams may use these procedures as well (other teams are required to maintain their own records of compliance, however).

Note that production environments are not operated by CLOUD_ART and are not in scope of this document.

## Key Compliance Objectives

1. security by design
2. operational compliance enablement
3. risk management in development
4. compliance documentation

## Risk Management Approach Summary

- **Risk assessment:** The project uses a combination of STRIDE-based risk assessments for specific features and the “Universal Cloud Threat Model” for the whole system.
- **Risk treatment:** The project implements a prevention-first approach via code analysis, access controls and environment isolation.
- **Risk prioritization:** Risks are prioritized based on exposure, exploitability and impact in context.
- **Risk monitoring:** We implement frequent risk reviews at the development level as well as release-time risk reviews at the ART level.

# Governance Framework

## Organizational Structure

CLOUD_ART development follows the SAFe Agile development process. The up to date team structure can be viewed Teams Overview Dashboard < Development < Documents & Pages < Teamcenter (scroll to "scrum teams" and search for "azure"). 

TcX and CLOUD_ART depends on these other organizations

FDS Autobahn: provides cloud-development infrastructure and services including Kubernetes, Gitlab, SAM
FDS CSO: provides cloud accounts, monitors cloud infrastructure, operates SIEM, drives incident response
Teamcenter development: delivers the Teamcenter product

(TODO: add org chart)

## Roles and Responsibilities

If you have any cybersecurity concerns, please reach out to your scrum master, PSSE or PSSO.

| Role | Person(s) | Responsibility |
| --- | --- | --- |
| PSSO | Laura Dominique | Responsible for Teamcenter X Product Security |
| PSSE | Benjamin Collar | Support and consult team on information security |
| PSSE | Shamsundar Machale | Support and consult team on information security |
| PSSE | Vikas Singh | Support and consult team on information security |
| Scrum Master | (See Roles and Responsibilities) | Respond to security issues, plan and delegate work to development |
| Developers | (See Roles and Responsibilities) | Implement necessary changes |
| RTE | (See Roles and Responsibilities) | Ensure ART works together and follows SAFE processes.  Facilitates ART events and processes and helps ensure value delivery. |
| ISMS Rep | Benjamin Collar | Ensure required ISMS activities are performed. Maintain ISMS document, procedures etc. |
| ISMS Rep (Azure) | Mandar Herlekar | Ensure required ISMS activities are performed. Maintain ISMS document, procedures etc. |
| ISMS Rep (AWS) | Ron Brickley | Ensure required ISMS activities are performed. Maintain ISMS document, procedures etc. |

## Shared Responsibility Model

(TODO: add link to SRM)

## Policy Framework

CLOUD_ART complies with ISO 27001 as per the DI SW ISMS Policies (TODO: LINK) to the extent required for development. Our aim is to produce a system that itself conforms to those policies and enables our operations team to comply. CLOUD_ART does not comply with SOC II type 2.

Relevant CLOUD_ART procedures and evidence are linked from this document.

RA 2025.xlsx (TODO: Link) (TODO: AWS) is the worksheet from QM team that is used to prepare for audits.

BIA and ACP are stored by the QM team in their sharepoint: TcX Azure (TODO: Link) (TODO: AWS)

The overall development process is SAFeAgile and governed by Index < Glossary of Working Agreements - LCS < Teamcenter (TODO: Link)