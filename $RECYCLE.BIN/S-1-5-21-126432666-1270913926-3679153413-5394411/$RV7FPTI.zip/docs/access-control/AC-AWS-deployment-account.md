# AC-AWS-DEP-001 - AWS Deployment Accounts Access Control Procedure

---

**1. General Information**

*   **Procedure ID:** `AC-AWS-DEP-001`
*   **Title:** `AWS Deployment Accounts Access Control Procedure`
*   **Version:** `1.0`
*   **Effective Date:** `2025-12-29`
*   **Review Date:** `2026-12-29`
*   **Owner:** `Benjamin Collar`
*   **Approver:** `RTE`

---

**2. Scope**

This procedure applies to TcX Development teams requiring access to AWS Deployment Accounts. It covers the process of granting and revoking access for users within these accounts.

---

**3. Purpose**

The purpose of this procedure is to ensure secure management and auditing of access to AWS Deployment Accounts for TcX, based on job role and the principle of least privilege. This includes controlling access based on business and security requirements, asset management policy, need-to-know basis, user access levels, roles, and deprovisioning processes.

---

**4. Related Controls / Standards (For Future OSCAL Alignment)**

*   **Internal Policy Reference:** `ISMS Policy - Access Control`
*   **External Standard Reference:** `ISO 27001:2022 A.5.1, NIST SP 800-53 AC-1, AC-2, AC-3`
*   **OSCAL Control ID (Future):** `TBD`

---

**5. Procedure Steps**

Follow these steps to implement and maintain the AWS Deployment Accounts Access Control Procedure:

1.  **Step 1: Request AWS Account Access**
    *   **Details:** When a new team member joins or an existing member requires access, the team leader/SCRUM master (who has admin access to AWS) initiates the process to add the user.
    *   **Verification:** User's need for access is approved by the team leader/SCRUM master.

2.  **Step 2: Grant Access via UASBOOT**
    *   **Details:** An AWS Account Administrator logs into UASBOOT, navigates to "Config" and then the "Manage User by Attributes" link on the left ribbon.
    *   **Tool/Link:** [UASBOOT](https://go.industrysoftware.automation.siemens.com/uasboot/)
    *   **Verification:** Administrator successfully logs into UASBOOT.

3.  **Step 3: Search and Add User Attributes**
    *   **Details:** Search for the user by their email ID. Once the valid user is found, click on "Add Attribute".
    *   **Verification:** User record is located and attribute addition initiated.

4.  **Step 4: Assign AWS Roles**
    *   **Details:** Select "aws_roles" in the "Attribute Name" field. Add the specific AWS Role(s) to the "Attribute Value" field, include relevant details in the "Notes" field, and click "Save".
    *   **Verification:** User is assigned the specified AWS roles and can log in using Siemens Windows credentials (SSO).

5.  **Step 5: Revoke Access**
    *   **Details:** To revoke access, the AWS Account Administrator uses UASBOOT to remove the relevant `aws_roles` attribute from the user's profile. This also aligns with the quarterly access review and deprovisioning processes.
    *   **Verification:** User's access to AWS Deployment Accounts is confirmed to be removed.

6. **Step 6: Review Access**
    * **Details:** TODO how is access reviewed?

---

**6. Definitions (Optional)**

*   **AWS:** Amazon Web Services, a comprehensive, broadly adopted, and secure cloud platform.
*   **UASBOOT:** Siemens internal tool for user access management.
*   **Least Privilege:** The security principle of giving an entity only the permissions needed to perform its function.

---

**7. References (Optional)**

*   [UASBOOT Portal](https://go.industrysoftware.automation.siemens.com/uasboot/)
*   Internal Policy: ISMS Policy - Access Control (Assumed)