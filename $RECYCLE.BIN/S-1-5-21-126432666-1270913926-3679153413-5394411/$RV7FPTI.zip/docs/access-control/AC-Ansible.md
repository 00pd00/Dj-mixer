# AC-ANSIBLE-001 - Ansible Development Tower Access Control Procedure

---

**1. General Information**

*   **Procedure ID:** `AC-ANSIBLE-001`
*   **Title:** `Ansible Development Tower Access Control Procedure`
*   **Version:** `1.0`
*   **Effective Date:** `2025-12-29`
*   **Review Date:** `2026-12-29`
*   **Owner:** `Benjamin Collar`
*   **Approver:** `Ansible Tower Administrator`

---

**2. Scope**

This procedure applies to TcX Development teams requiring access to Ansible Development Tower. It covers the process of granting and revoking access to Ansible Tower accounts.

---

**3. Purpose**

The purpose of this procedure is to ensure secure management and auditing of access to Ansible Development Tower for TcX, based on job role and the principle of least privilege. This includes controlling access based on business and security requirements, asset management policy, need-to-know basis, user access levels, roles, and deprovisioning processes.

---

**4. Related Controls / Standards (For Future OSCAL Alignment)**

*   **Internal Policy Reference:** `ISMS Policy - Access Control`
*   **External Standard Reference:** `ISO 27001:2022 A.5.1, NIST SP 800-53 AC-1, AC-2, AC-3`
*   **OSCAL Control ID (Future):** `TBD`

---

**5. Procedure Steps**

Follow these steps to grant, revoke or review Ansible Tower access:

1.  **Step 1: Request Ansible Tower Access**
    *   **Details:** Team members requiring access to Ansible Development Tower should submit a request to their manager.
    *   **Verification:** Request is reviewed and approved by the manager.
    *   Note that request emails are not specifically archived

2.  **Step 2: Grant Ansible Tower Access**
    *   **Details:** TODO how is ansible tower access granted now?
    *   **Verification:** User is able to access Ansible Development Tower with appropriate permissions.

3.  **Step 3: Revoke Ansible Tower Access**
    *   **Details:** TODO how is ansible tower access revoked now?
    *   **Verification:** User's access to Ansible Development Tower is confirmed to be removed.

4. **Step 4: Review Ansible Tower Access**
    * **Details:** TODO how is this reviewed?
    * **Verfication:** TODO how is the verified?

---

**6. Definitions (Optional)**

*   **Ansible Development Tower:** A web-based solution that makes Ansible easier to use for IT teams of all sizes.
*   **Least Privilege:** The security principle of giving an entity only the permissions needed to perform its function.

---

**7. References (Optional)**

*   Internal Policy: ISMS Policy - Access Control (Assumed)
*   Ansible Tower Documentation (General reference)