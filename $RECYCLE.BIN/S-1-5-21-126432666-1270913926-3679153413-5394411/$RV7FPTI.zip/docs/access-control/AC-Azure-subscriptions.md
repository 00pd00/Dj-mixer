Here is the complete procedure, output as clean, well-formatted Markdown:

# PROC-TCX-AC-AZ-001 — Teamcenter-X Access Control Procedure for Azure

> **Classification:** Restricted © Siemens 2023
> **Policy Tag:** SISW SaaS Access Control Policy

---

## 1. General Information

| Field            | Value                                              |
|------------------|----------------------------------------------------|
| **Procedure ID** | PROC-TCX-AC-AZ-001                                 |
| **Title**        | Teamcenter-X Access Control Procedure for Azure    |
| **Version**      | 0.4                                                |
| **Effective Date** | 2025-07-18                                       |
| **Review Date**  | 2026-07-18 *(annual review required)*              |
| **Owner**        | Entra ID Group Owner / Subscription Owner          |
| **Approver**     | *(Insert approval proof — pending)*                |

### Version History

| S.NO | Date       | Version | Description                            |
|------|------------|---------|----------------------------------------|
| 1    | 2024-09-11 | 0.1     | Provisional procedure                  |
| 2    | 2024-12-06 | 0.2     | Updated procedure                      |
| 3    | 2024-12-20 | 0.3     | Final draft                            |
| 4    | 2025-07-18 | 0.4     | Update with new Teams Approval App method |

---

## 2. Scope

This procedure applies to all Teamcenter-X (TcX) personnel — including developers,
engineers, scrum masters, and managers — who require access to Microsoft Azure
resources within the SPLM Azure Tenant.

**In scope:**

- Microsoft Azure only (**not** AWS)
- Definition of groups, roles, and permission sets within Microsoft Entra ID
- Detailed procedures for users requesting access
- Detailed procedures for administrators managing users, groups, and role assignments
- Definition of the access review procedure

---

## 3. Purpose

The purpose of this procedure is to define and govern how access to Azure resources
is requested, granted, managed, and reviewed within the Teamcenter-X project,
in accordance with the **principle of least privilege** and the
**SISW SaaS Access Control Policy**.

It ensures that:

- Only authorized personnel have access to Azure resources
- Access is time-bound where possible using Privileged Identity Management (PIM)
- Access rights are periodically reviewed and revoked when no longer needed

---

## 4. Related Controls

### 4.1 Standards &amp; Policies

| Type                        | Reference                                                                 |
|-----------------------------|---------------------------------------------------------------------------|
| **Internal Policy**         | SISW SaaS Access Control Policy *(SISW SaaS Access Control Policy.pdf)*  |
| **External Standard**       | ISO/IEC 27001:2022; NIST 800-171                                          |
| **OSCAL Control ID**        | *(To be assigned)*                                                        |

### 4.2 SISW Policy Cross-References

| Policy Requirement | Relevance to This Procedure |
|---|---|
| **SISW AC §1.1** — Processes for assignment of access rights, including privileged access rights, must be established | This procedure defines the full access assignment process for Azure |
| **SISW AC §1.1.1** — The process for assigning access rights must be defined, documented, and reviewed annually | This procedure fulfills this requirement; review date set annually |
| **SISW AC §1.1.2** — A formal user registration and deregistration procedure must be established using unique user IDs | Covered by Entra ID onboarding steps and use of Siemens GID / SPLM ID |
| **SISW AC §1.1.3** — Records of account creation and access approval must be retained | Azure and Entra maintain records; stored in ISMS Activity Records |
| **SISW AC §1.1.4** — User access must be assigned on a need-to-know basis | Enforced via group-based access and manager approval via Teams App |
| **SISW AC §1.1.5** — Default user privileges must be granted based on job function | Roles are assigned to groups aligned to job function; users activate membership as needed |
| **SISW AC §1.1.6** — Service accounts shall have an assigned responsible person | Groups must have a minimum of 2 nominated owners |
| **SISW AC §1.1.7** — Approval must be obtained and documented prior to granting access | Enforced via Teams Approval App workflow |
| **SISW AC §1.2.4** — Management must perform periodic review of access rights | Covered by the manual Access Review procedure |
| **SISW AC §1.4 / §1.4.1** — Access must be reviewed at least every 6 months and documented | Access review records stored in ISMS Activity Records (2025) |
| **SISW AC §1.5.1** — Process for disabling inactive/unauthorized accounts must be defined | Administrators must remove or update assignments identified during access reviews |
| **SISW AC §1.5.2** — Upon termination, access must be disabled within one business day | Managers must notify the Entra ID Group Owner promptly upon personnel changes |
| **SISW IS Policy §1.1.7** — A separation of roles must exist within the user access management lifecycle | Enforced by distinct roles: Manager, Entra ID Group Owner, Subscription Owner, Scrum Master |

---

## 5. Roles and Responsibilities

| Role | Responsibilities |
|---|---|
| **User / Team Member** | Submits access requests via the Teams Approval App; activates PIM group membership when access is needed |
| **Manager** | Approves or denies access requests; notifies the Entra ID Group Owner when a user's membership should be added or removed |
| **Scrum Master** | Acts as delegate of the Manager for access approval purposes |
| **Entra ID Group Owner** | Defines and manages Entra security groups; enables PIM for groups; assigns and removes members; sets up access reviews |
| **Subscription Owner** | Assigns and removes Azure roles to/from Entra Groups at the subscription level |
| **DI SW Enterprise Foundation Team** *(ad_admins.siswg@Siemens.com)* | Resolves Entra ID issues where a user's Siemens GID is not associated with their SPLM ID |

> 📌 *Cross-reference: SISW IS Policy §1.1.7 — A separation of roles must exist within
> the user access management lifecycle.*

---

## 6. Principles

- The project follows the **least-privilege principle** at all times.
- The project acknowledges the working phase of the project and its changing dimensions.
- **Privileged Identity Management (PIM)** functions shall be used to reduce persistent
  access to Azure resources.
- Human actors activate their **Entra PIM-Enabled Group Membership**.
  Entra PIM-Enabled Groups hold active roles on Azure resources.

> ⚠️ **Important:** It is possible to assign roles directly to users rather than via
> groups, but this causes more difficulties for the user and is **not** the preferred
> approach.

---

## 7. Procedure Steps

---

### Step 1 — User: Submit an Access Request

**Actor:** User / Team Member
**Trigger:** User requires access to Azure resources, Keycloak groups, or Vault tokens.

#### Instructions

1. Join the **TC and TcX Security Approvals** Microsoft Teams team.
2. Submit an approval request via the Teams App, specifying:
   - The approving **Manager** or **Scrum Master**
   - The type of access required (select one or more):
     - Azure group and subscription access
     - Keycloak Group Membership
     - Become Vault Token Generator
     - Request TcX Vault Token

#### Verification

- Confirmation of request submission is received within the Teams App.
- The approving Manager or Scrum Master receives the request for action.

> 📌 *Cross-reference: SISW AC §1.1.7 — Approval must be obtained and documented
> prior to granting access.*

---

### Step 2 — Administrator: Add a User to Entra

**Actor:** Entra ID Group Owner / DI SW Enterprise Foundation Team
**Trigger:** A user's access request has been approved and they need to be registered
in Entra before Azure access can be granted.

#### 2a. Adding a User with a Siemens SPLM ID *(standard case)*

1. Navigate to [https://entra.microsoft.com](https://entra.microsoft.com).
2. Verify the user is present in Entra by searching for their Siemens GID.
3. If the user **does not** appear in Entra, open a SNOW incident:
   - Portal: `https://diswsiemens.service-now.com/sp`
   - Select: **DISW: Report an Incident**
   - Request the ticket be forwarded to the **DI SW Enterprise Foundation** team
     at `ad_admins.siswg@Siemens.com`
   - Specify that this is for the SPLM tenant.

#### 2b. Adding an External User *(without an SPLM ID — rare)*

1. "Invite" the user to the SPLM Azure Tenant via Entra.
2. This applies **only** to users registering with an external email address
   (e.g., `@externalcompany.com`).
3. This step is **rarely** required.

#### Verification

- User appears in [https://entra.microsoft.com](https://entra.microsoft.com)
  with the correct identity association confirmed.

> 📌 *Cross-reference: SISW AC §1.1.2 — A formal user registration procedure must
> be established using unique user IDs.*

---

### Step 3 — Administrator: Add or Remove a User to/from a Group

**Actor:** Entra ID Group Owner
**Trigger:** An approved access request requires a user to be added to a group,
or a user's access is being revoked.

> **Design principle:** Rather than granting roles directly to individuals, individuals
> are assigned to groups that have roles assigned to them. Users then activate their
> group membership to gain access.

#### Instructions — Add a User

1. Log in to [https://entra.microsoft.com](https://entra.microsoft.com).
2. Navigate to **Identity Governance → Privileged Identity Management → Groups**
   (under **Manage**).
3. Select the relevant group.
4. Click **Manage → Assignments**.
5. Add the user as a member, setting the membership type to **`Eligible`**.

#### Instructions — Remove a User

1. Follow steps 1–4 above.
2. Locate the user in the assignments list.
3. Select **Remove** next to the user's entry.

#### Verification

- The user appears (or no longer appears) in the group's **Eligible Assignments** list.

> 📌 *Cross-reference: SISW AC §1.1.4 — User access must be assigned on a need-to-know
> basis; §1.5.3 — Procedures must be established for access modification within a
> defined time period.*

---

### Step 4 — Administrator: Create a New Group

**Actor:** Entra ID Group Owner
**Trigger:** A new access scope or project role requires a new Entra security group.

#### Instructions

1. Log in to [https://entra.microsoft.com](https://entra.microsoft.com).
2. Activate the role **`DISWCreateGRP_Subscription_Owner`** via PIM.
   > This role can be requested via a DISW SNOW ticket. Specify it is for the SPLM
   > tenant and that the ticket should be assigned to the **Azure Cloud Security
   > (DISW-L2)** group.
3. Navigate to **Groups → New Group**.
4. Configure the group as follows:

   | Field              | Value                                        |
   |--------------------|----------------------------------------------|
   | **Group Type**     | Security                                     |
   | **Group Name**     | Use the `TcX` prefix (e.g., `TcXonSub Contributors`) |
   | **Membership Type**| Assigned                                     |
   | **Owners**         | Select a minimum of **2 owners**             |
   | **Members**        | None initially                               |

5. After creation, locate the group in the list.
6. Select the group and **enable Privileged Identity Management (PIM)** for it.
   > PIM enables just-in-time (JIT) access to the ownership or membership of the group.

#### Verification

- The new group appears in the Entra groups list with PIM enabled and at least
  2 owners assigned.
- Group name begins with `TcX` per naming convention.

> 📌 *Cross-reference: SISW AC §1.1.6 — Service accounts and shared user accounts
> shall have an assigned person who holds overall responsibility.*

---

### Step 5 — Administrator: Assign Roles to a Group

**Actor:** Subscription Owner
**Trigger:** A new group has been created and requires Azure role assignments,
or an existing group's roles need to be updated.

#### Instructions

1. Navigate to [https://portal.azure.com](https://portal.azure.com).
2. Navigate to the target resource (management group, subscription, resource group,
   or direct resource). *These instructions focus on the subscription level.*
3. Go to **Access Control (IAM) → Add Role Assignment**.
4. Find and select the desired role.
5. Select the **Entra group** (not an individual user) as the assignee.
6. Set the assignment configuration:

   | Field               | Value                    |
   |---------------------|--------------------------|
   | **Assignment Type** | Active                   |
   | **Duration**        | Permanent                |

   > ⚠️ **For Entra PIM Groups, the assignment MUST be ACTIVE.** This means the group
   > holds the role permanently, and users activate their *group membership* (not the
   > role directly) to gain access. This allows grouping of multiple roles, reducing
   > the number of individual activations a user must perform.

7. For the initial project phase, **built-in roles** are used. Custom roles may be
   introduced following further analysis to determine whether smaller-scoped built-in
   roles are adequate.

#### Verification

In the subscription's **Access Control (IAM)** page, under
**Privileged Administrator Roles → Type: Group**, confirm:

- [ ] Group **State** is `Active Permanent`
- [ ] Group **End time** is `Permanent`
- [ ] Group has the expected role assignment

> 📌 *Cross-reference: SISW AC §1.1.5 — Default user privileges and administrative
> access must be granted based on job function; §1.1 — Least privilege principle
> must be applied.*

---

### Step 6 — User: Activate PIM Group Membership

**Actor:** User / Team Member
**Trigger:** User needs to exercise their Azure access for a task or work session.

#### Instructions

1. Log in to [https://entra.microsoft.com](https://entra.microsoft.com).
2. Navigate to **Privileged Identity Management → My Roles → Groups**.
3. Locate the relevant group under **Eligible Assignments**.
4. Select **Activate**.
5. Provide a justification for the activation as prompted.

#### Verification

- The user's membership moves to **Active Assignments** for the duration of the
  activation window.

> 📌 *Cross-reference: SISW AC §1.1 — PIM functions are used to reduce persistent
> access to Azure resources, in line with the least-privilege principle.*

---

### Step 7 — Administrator: Conduct Access Reviews

**Actor:** Entra ID Group Owner / Subscription Owner
**Trigger:** Scheduled access review (minimum every 6 months) or ad-hoc review
following a personnel change.

> **Note:** Automated Entra/Azure tool-supported access reviews are **not currently
> available** due to insufficient role assignments. All access reviews are performed
> **manually** and focus on **Privileged Administrator Roles only.**

#### 7a. Review PIM Group Members

1. Navigate to **Azure Portal → Subscription → Access Control (IAM) →
   Role Assignments → Privileged Administrator Roles**.
2. Filter by **Scope: Subscription** and **Type: Group**.
3. For each group, verify:
   - [ ] **State** is `Active Permanent`
   - [ ] **End time** is `Permanent`
   - [ ] Group has the expected role assignment
4. Navigate to **Activity → Privileged Identity Management → Eligible Assignments**.
5. For each listed user, verify they should continue to be a member of the group.
6. **Remove or update** assignments as required.
7. Navigate to **Active Assignments** and review group owners.
8. Verify that listed users should continue to be group owners.
   Remove or update as required.

#### 7b. Review Direct / Non-PIM Access

1. In the subscription **Access Control (IAM)** page, filter by **Type: User**.
2. Verify that no users have direct privileged role assignments.
   > Generally, **there should be none** — all privileged access should flow
   > through PIM-enabled groups.
3. If any direct user assignments are found, investigate and remediate.

#### Verification

- All findings and remediation actions are documented and stored in
  **ISMS Activity Records (2025)**.

> 📌 *Cross-reference: SISW AC §1.4 — Access to information resources must be
> reviewed on a periodic basis; §1.4.1 — Review must be performed at least every
> 6 months and documented; §1.5.1 — The process for disabling inactive or
> unauthorized accounts must be defined, documented, and logged.*

---

## 8. Definitions

| Term | Definition |
|---|---|
| **Azure** | Microsoft's cloud computing platform, used to host Teamcenter-X infrastructure |
| **Entra ID** | Microsoft's cloud-based identity and access management service (formerly Azure Active Directory) |
| **PIM** *(Privileged Identity Management)* | A Microsoft Entra ID Governance feature enabling just-in-time (JIT), time-bound, and approval-based access to privileged roles and group memberships |
| **Least Privilege** | The security principle of granting an entity only the minimum permissions needed to perform its required function |
| **SPLM ID** | Siemens PLM Software identity, used to associate a user's Siemens GID with their Azure/Entra access |
| **Siemens GID** | Global identifier for a Siemens employee, used as the basis for identity in Entra |
| **Eligible Assignment** | A PIM assignment type where the user must explicitly activate their access before it becomes effective |
| **Active Assignment** | A PIM assignment type where access is permanently active without requiring user activation |
| **SNOW** | ServiceNow — the ITSM ticketing system used to raise incidents and service requests at Siemens |
| **TcX** | Abbreviation for Teamcenter-X, the Siemens SaaS PLM product hosted on Azure |
| **IAM** | Identity and Access Management — the discipline of controlling who has access to what resources |
| **JIT** | Just-in-Time access — a security model where access is granted only when needed and for a limited duration |
| **SP** | Service Principal — a non-human identity used by applications or services to access Azure resources |

---

## 9. Records

| Record | Location | Retention |
|---|---|---|
| Group creation records | Azure and Entra ID *(all groups prefixed `TcX`)* | Per SISW records retention policy |
| Access approval records | Teams Approval App logs | Per SISW records retention policy |
| Access review records | ISMS Activity Records (2025) | Minimum 6 months per SISW AC §1.4.1 |

---

## 10. References

| Reference | Description |
|---|---|
| **SISW SaaS Access Control Policy** | Authoritative internal policy governing all access control requirements *(SISW SaaS Access Control Policy.pdf)* |
| **SISW SaaS ISMS Policy Document** | Journey to ISO 27001: SISW SaaS ISMS Policy Searchable Page |
| **ISO/IEC 27001:2022** | Information Security Management Systems — Requirements |
| **NIST 800-171** | Protecting Controlled Unclassified Information in Nonfederal Systems |
| **Microsoft Learn: PIM for Groups** | [Privileged Identity Management (PIM) for Groups — Microsoft Entra ID Governance](https://learn.microsoft.com/en-us/entra/id-governance/privileged-identity-management/concept-pim-for-groups) |
| **ISMS Activity Records (2025)** | Repository for access review records |
| **DISW ServiceNow Portal** | `https://diswsiemens.service-now.com/sp` — for incident and access request tickets |