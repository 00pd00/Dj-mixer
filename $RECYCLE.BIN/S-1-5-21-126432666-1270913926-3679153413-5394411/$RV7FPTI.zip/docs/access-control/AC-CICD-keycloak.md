# AC-CICD-001 - Access Control to CICD

---

**1. General Information**

*   **Procedure ID:** `AC-CICD-001`
*   **Title:** `Access Control to CICD`
*   **Version:** `1.0`
*   **Effective Date:** `2025-12-29`
*   **Review Date:** `2026-12-29`
*   **Owner:** `Benjamin Collar`
*   **Approver:** `RTE`

---

**2. Scope**

This procedure applies to FDS-operated infrastructure such as Rancher, Harbor and ArgoCD. It covers granting, revoking and reviewing access to these infrastructure items.

---

**3. Purpose**

The purpose of this procedure is to ensure that access to the CI/CD infrastructure is managed securely, follows the principle of least privilege, and is regularly reviewed to prevent unauthorized access and maintain compliance with internal policies and external regulations.

---

**4. Related Controls / Standards (For Future OSCAL Alignment)**

*   **Internal Policy Reference:** `[e.g., ISMS Policy - Access Control]`
*   **External Standard Reference:** `[e.g., ISO 27001:2022 A.5.1, NIST SP 800-53 AC-1, AC-2, AC-3]`
*   **OSCAL Control ID (Future):** `TBD`

---

**5. Procedure Steps**

### Procedure for requesting access
Follow these steps to implement and maintain `Access Control to CICD`:

1.  **Step 1: Join the TC Approvals Team**
    *   **Details:** Join the MS Teams called [TC and TcX Security Approvals | General | Microsoft Teams](https://teams.microsoft.com/l/team/19%3A5hfrYEH8SUgZj2TuDnZi3wDOsZjcFnvazzYcYZsV8ZM1%40thread.tacv2/conversations?groupId=e884d470-82e2-4f56-bf49-ba8bf28bc2d4&tenantId=38ae3bcd-9579-4fd4-adda-b42e1495d55a). Ensure your selected approver (e.g. Scrum Master or Manager) has also joined the team.
    *   **Verification:** Your request will be sent to the team owner. When it has been approved you'll get a notification in MS Teams and the Team will be present in your list.

2.  **Step 2: Complete approval form**
    *   **Details:** Complete the approval form called [Keycloak Group Membership](https://teams.microsoft.com/l/entity/7c316234-ded0-4f95-8a83-8453d0876592/approvals/?context=%7B%22subEntityId%22%3A%220P55753W120RMKXPJ4Y2NP4VMDBWTEXE71WSBN2FNQDB8BGMJQANMW6MGKME50JP9YZMKEMBYA5W5N0%3A%3AshareLink%3A%22%7D).
    *   **Verification:** Once you click "Send" the form will be routed to the approvers automatically. In the approval tool you can view the status of your request.

3.  **Step 3: Wait for approval and execution**
    *   **Details:** Once the approvals have been secured, the tool owners will grant access
    *   **Verification:** The approval tool will notify you when access has been granted. Verify your access by viewing Harbor / Rancher / ArgoCD

### Procedure for approving, granting, revoking and reviewing access

1. **Step 1: Process approval requests**
    * **Details:** you will receive a notification in Teams. Either approve or reject with comments.
    * **Verification:** MS Teams will post a notification with your result. You can also see all previous approval requests and their status.

    It may be that you can only approve or reject requests; keycloak group admins thereafter perform the following steps:

2. **Step 2: Grant access**
    * **Details:** Authenticate to Keycloak as a member of the tcx-keycloak-admin group. Add the requester to the appropriate keycloak groups.
    * **Verification:** The member's ID will be listed in the keycloak member list

3. **Step 3: Revoke access**
    * **Details:** Authenticate to keycloak as a member of the tcx-keycloak-admin group. Search for the ID of the person to be removed. Check their group memberships and remove them from relevant groups.
    * **Verification:** View the relevant groups and ensure the person's ID is no longer listed there

4. **Step 4: Review access**
    * **Details:** Authenticate to keycloak (any member type is adequate). Check the member list of each known group. In case a person should not longer be a member of the group, open a [TcX Developer Offboarding](https://teams.microsoft.com/l/entity/7c316234-ded0-4f95-8a83-8453d0876592/approvals/?context=%7B%22subEntityId%22%3A%220P9S303BH67G0HDJJ0JV9DR93A5WTEXE71WSBN2FNQDB8BGMJQANMW6MGKME50JP9YZMKEMBYA5W5N0%3A%3AshareLink%3A%22%7D) request
---

**6. Definitions (Optional)**

*   **Least Privilege:** The security principle of giving an entity only the permissions needed to perform its function.

---

**7. References (Optional)**

* MS Teams has an application called "Approvals". In case the approval form links are not working, you can navigate to them directly via the Approvals app (after you have joined the team)
* See [TcX Harbor Design](https://siemensnam.sharepoint.com/teams/disw_plc_coi_fdo/cyber/SitePages/TcX%20Harbor%20Design.aspx)
* See [Keycloak Group List](https://mypolarion.industrysoftware.automation.siemens.com/polarion/#/project/Teamcenter/wiki/Asset%20Inventory/External%20Dependencies)