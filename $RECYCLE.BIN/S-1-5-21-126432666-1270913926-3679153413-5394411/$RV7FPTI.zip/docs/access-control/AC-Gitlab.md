# AC-GIT-001 - GitLab Access Control Procedure

---

**1. General Information**

*   **Procedure ID:** `AC-GIT-001`
*   **Title:** `GitLab Access Control Procedure`
*   **Version:** `1.0`
*   **Effective Date:** `2025-12-29`
*   **Review Date:** `2026-12-29`
*   **Owner:** `Benjamin Collar`
*   **Approver:** `RTE`

---

**2. Scope**

This procedure applies to all TcX Development teams requiring access to GitLab. It covers the process of granting and revoking access to both entire TcX GitLab Groups and specific project repositories.

---

**3. Purpose**

The purpose of this procedure is to ensure secure management and auditing of access to GitLab accounts for TcX, based on job role and the principle of least privilege. This includes controlling access based on business and security requirements, asset management policy, need-to-know basis, user access levels, roles, and deprovisioning processes.

---

**4. Related Controls / Standards (For Future OSCAL Alignment)**

*   **Internal Policy Reference:** `ISMS Policy - Access Control`
*   **External Standard Reference:** `ISO 27001:2022 A.5.1, NIST SP 800-53 AC-1, AC-2, AC-3`
*   **OSCAL Control ID (Future):** `TBD`

---

**5. Procedure Steps**

Follow these steps to implement and maintain the GitLab Access Control Procedure:

1.  **Step 1: Request GitLab License (Overall Access)**
    *   **Details:** The employee or their delegate must raise a GitLab License Request via the specified Service-Now portal.
    *   **Tool/Link:** [DISW: GitLab License Request Form](DISW:GitLab License Request Form) TODO: link
    *   **Verification:** Confirmation of license request submission and processing.

2.  **Step 2: Request Access to TcX GitLab Group or Repository**
    *   **Details:** The requester (team member) sends an email to their manager requesting access to either an entire TcX GitLab Group or specific project repositories. If approved, the manager forwards this request to the relevant repository or group administrator.
    *   **Example:**
        ```
        To: <Manager's Email>
        Subject: TCX: Request access to GitLab Project(s)
        Body: Please grant me access to [specific GitLab Group/Repository name(s)] for [reason/project].
        ```
    *   **Verification:** Confirmation email from manager/administrator, or direct access to the requested GitLab resources.

3.  **Step 3: Revoke Access**
    *   **Details:** Access to GitLab must be revoked upon employee resignation, change of privileges, or movement to another department. This is also part of the quarterly access review process. The manager approves the revocation, and the repository/group administrator removes the access.
    *   **Verification:** User's access to GitLab is confirmed to be removed.

4. **Step 4: Review Access**
    * **Details:** On a monthly basis, the gitlab administrators produce an access excel table and send to the PSSE's. These are saved in the access review folder. During regular access reviews (TODO: add link to schedule), these tables are reviewed.
---

**6. Definitions (Optional)**

*   **GitLab:** A web-based DevOps lifecycle tool that provides a Git repository manager with wiki, issue-tracking, CI/CD pipeline, and other features.
*   **Least Privilege:** The security principle of giving an entity only the permissions needed to perform its function.

---

**7. References (Optional)**

*   [DISW: GitLab License Request Form](DISW:GitLab License Request Form)
*   Internal Policy: ISMS Policy - Access Control (Assumed)