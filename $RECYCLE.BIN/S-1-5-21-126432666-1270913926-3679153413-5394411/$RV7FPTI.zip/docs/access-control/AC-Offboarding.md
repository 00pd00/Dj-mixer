# AC-OFF-001 - TcX Developer Offboarding

---

**1. General Information**

*   **Procedure ID:** `AC-OFF-001`
*   **Title:** `TcX Developer Offboarding`
*   **Version:** `1.0`
*   **Effective Date:** `2025-12-30`
*   **Review Date:** `2026-12-30`
*   **Owner:** `Benajmin Collar`
*   **Approver:** `RTE`

---

**2. Scope**

This procedure applies to all development personnel in CLOUD_ART or who are otherwise goverened by the ISO 27001 policies. (For example, integration developers may temporarily be granted access to CLOUD_ART assets). This procedure covers revocation of access, referring to other procedures.

---

**3. Purpose**

The purpose of this procedure is to ensure that access to ISMS-governed assets is managed securely, particularly when a person no longer requires access.

---

**4. Related Controls / Standards (For Future OSCAL Alignment)**

*   **Internal Policy Reference:** `[e.g., ISMS Policy - Access Control]`
*   **External Standard Reference:** `[e.g., ISO 27001:2022 A.5.1, NIST SP 800-53 AC-1, AC-2, AC-3]`
*   **OSCAL Control ID (Future):** `TBD`

---

**5. Procedure Steps**

Follow these steps to implement and maintain `TcX Developer Offboarding`:

1.  **Step 1: Send offboarding request**
    *   **Details:** The manager responsible for offboarding the developer should send an [TcX Developer Offboarding](https://teams.microsoft.com/l/entity/7c316234-ded0-4f95-8a83-8453d0876592/approvals/?context=%7B%22subEntityId%22%3A%220P9S303BH67G0HDJJ0JV9DR93A5WTEXE71WSBN2FNQDB8BGMJQANMW6MGKME50JP9YZMKEMBYA5W5N0%3A%3AshareLink%3A%22%7D) request
    *   **Verification:** The approval system will notify the sender that the request has been sent, as well as its current status.

2.  **Step 2: Execute offboarding**
    *   **Details:** The system administrators will revoke access to the various systems, as specified in the offboarding request. The administrators will perform a quick review of additional systems in scope; however, it is the manager's responsibility to specify fully which systems the person had access to! Once the revocations are completed, the administrator will mark the request accordingly.
    *   **Verification:** See verification for the individual systems

---

**6. Definitions (Optional)**

---

**7. References (Optional)**
