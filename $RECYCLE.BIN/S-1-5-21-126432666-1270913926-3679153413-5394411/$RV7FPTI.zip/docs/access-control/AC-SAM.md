# AC-SAM-001 - Security and Access Management (SAM) Accounts Access Control Procedure

---

**1. General Information**

*   **Procedure ID:** `AC-SAM-001`
*   **Title:** `Security and Access Management (SAM) Accounts Access Control Procedure`
*   **Version:** `1.0`
*   **Effective Date:** `2025-12-29`
*   **Review Date:** `2026-12-29`
*   **Owner:** `Teamcenter-X Team Lead / Scrum Master`
*   **Approver:** `SAM Account Administrator / CISO`

---

**2. Scope**

This procedure applies to TcX users requiring access to Security and Access Management (SAM) accounts, which are used for volume storage and provide Webkey authentications for SSO logins.

---

**3. Purpose**

The purpose of this procedure is to ensure secure management and auditing of access to Security and Access Management (SAM) accounts for TcX, which are critical for volume storage and Webkey-based SSO logins. This includes controlling access based on business and security requirements, asset management policy, need-to-know basis, user access levels, roles, and deprovisioning processes.

---

**4. Related Controls / Standards (For Future OSCAL Alignment)**

*   **Internal Policy Reference:** `ISMS Policy - Access Control`
*   **External Standard Reference:** `ISO 27001:2022 A.5.1, NIST SP 800-53 AC-1, AC-2, AC-3, IA-2`
*   **OSCAL Control ID (Future):** `TBD`

---

**5. Procedure Steps**

Follow these steps to implement and maintain the Security and Access Management (SAM) Accounts Access Control Procedure:

1.  **Step 1: Request SAM Account Access**
    *   **Details:** A Teamcenter-X team member requiring access to SAM accounts must send an email request to their manager.
    *   **Example:**
        ```
        To: <Employee's Manager's email>
        Subject: TCX: Request access to SAM account(s)
        Body: Please grant me access to the SAM accounts for doing development/testing activities.
        ```
    *   **Verification:** Manager receives and reviews the email request.

2.  **Step 2: Grant SAM Account Access** TODO: no details? Also add procedures for reviewing
    *   **Details:** After receiving the email, the Manager or the Admin in the team grants access to the SAM account to the user. This should be based on the principle of least privilege and approved business need.
    *   **Verification:** User is able to log in via Webkey authentications and access necessary volume storage or SSO services.

3.  **Step 3: Revoke SAM Account Access**
    *   **Details:** Access to SAM accounts should be revoked upon employee resignation, change of privileges, or movement to another department, and as part of the quarterly access review process. The Manager or Admin in the team is responsible for revoking this access.
    *   **Verification:** User's access to SAM accounts is confirmed to be removed.

---

**6. Definitions (Optional)**

*   **SAM Accounts:** Security and Access Management accounts, used for volume storage and providing Webkey authentications for SSO logins for Teamcenter-X users.
*   **Webkey Authentications:** Siemens-specific authentication mechanism, likely integrated with SSO.
*   **Least Privilege:** The security principle of giving an entity only the permissions needed to perform its function.

---

**7. References (Optional)**

*   Internal Policy: ISMS Policy - Access Control (Assumed)