---
id: data-classification-standard
title: Data Classification Standard
---

# Data Classification Standard

This standard defines how information is classified, handled, shared, and protected across ISMS-managed systems.

## Classification Levels

1. Public
2. Internal
3. Confidential
4. Restricted

## Handling Requirements

- Access to Confidential and Restricted data must follow least-privilege principles.
- Data sharing outside approved systems requires owner approval.
- Backup and retention must align with business and regulatory requirements.
- Incidents involving Confidential or Restricted data must be reported immediately.

## Ownership and Review

- Owner: ISMS Team
- Review cycle: Annual or after major regulatory or business changes
