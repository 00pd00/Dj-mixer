# IM-Incident-001 - TcX Incident Management

---

**1. General Information**

*   **Procedure ID:** `IM-Incident-001`
*   **Title:** `TcX Incident Management`
*   **Version:** `1.0`
*   **Effective Date:** `2025-12-30`
*   **Review Date:** `2026-12-30` (e.g., 1 year from effective date)
*   **Owner:** `Benjamin Collar`
*   **Approver:** `RTE`

---

**2. Scope**

This procedure applies to all TcX Development activities and resources allocated to or managed by CLOUD_ART personnel. It covers notification and management of incidents.
---

**3. Purpose**

The purpose of this procedure is to clarify the roles, responsibilities and actions of CLOUD_ART and other personnel with respect to cybersecurity incidents. 

---

**4. Related Controls / Standards (For Future OSCAL Alignment)**

*   **Internal Policy Reference:** `[e.g., ISMS Policy - Access Control]`
*   **External Standard Reference:** `[e.g., ISO 27001:2022 A.5.1, NIST SP 800-53 AC-1, AC-2, AC-3]`
*   **OSCAL Control ID (Future):** `TBD`

---

**5. Procedure Steps**

Follow these steps to implement and maintain `TcX Incident Management`:

1.  **Notify that an incident may have occured**
    *   **Details:** If any employee suspects there may be a security incident, they should [report an incident](https://diswsiemens.service-now.com/sp?id=sc_cat_item&sys_id=b5ef40dbc3c0f6981b27bc33e40131cb&sysparm_category=c56fb20b1b1844106384a796bd4bcba3)
    *   **Verification:** Submitter will receive an email.

2.  **Participate in incident handling**
    *   **Details:** CLOUD_ART personnel may be called upon to support incident handling. The process is described in [FDS Incident Response](https://developer.internal.siemens.com/fds/p0/sec_ops/incident-response/index.html) . CLOUD_ART personnel should inform their management and PSSE regarding their participation.

---

**6. Definitions (Optional)**


---

**7. References (Optional)**
